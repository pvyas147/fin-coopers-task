const baseUrl = {
    "adminBaseUrl":process.env.NEXT_PUBLIC_ADMIN_API_BASEURL
}


export { baseUrl }