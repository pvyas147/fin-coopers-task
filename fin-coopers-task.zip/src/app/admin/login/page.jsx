import AdminLoginPage from "../../../Container/AdminPages/AdminLoginPage"



const AdminLogin = () => {
  return (
   <><AdminLoginPage/></>
  )
}

export default AdminLogin