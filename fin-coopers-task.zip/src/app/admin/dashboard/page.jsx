import React from 'react'
import Dashboard from '../../../Container/AdminPages/Dashboard';

const AdminDashboardPage = () => {
  return (
 <Dashboard/>
  )
}

export default AdminDashboardPage;