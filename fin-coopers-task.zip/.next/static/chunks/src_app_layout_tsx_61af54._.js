(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__7818e7._.css",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_framer-motion_dist_es_ec36d6._.js",
    "static/chunks/node_modules_7e770b._.js",
    "static/chunks/_f0d6ef._.js"
  ],
  "source": "dynamic"
});
